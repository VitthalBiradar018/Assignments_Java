package test;

import java.util.Enumeration;
import java.util.Vector;

public class VectorEnum {

	public static void main(String[] args) {
		
		Vector<String> v =  new Vector<>();
		
		v.add("Kawasaki");
		v.add("Ducati");
		v.add("BMW");
		v.add("Harley Davidson");
		v.add("Triumph");
		v.add("Beneli");
		v.add("RE Gt 650");
		
		
		Enumeration<String> e1 = v.elements(); 
		
		while(e1.hasMoreElements()) {
			String bike = e1.nextElement();
			System.out.println(bike);
		}
	}

}
