package com.demo.dao;

import com.demo.bean.Friend;
import com.demo.service.IFriendService;

import java.util.List;
import java.time.LocalDate;
import java.util.ArrayList;

public class FriendDao implements IFriendDao {
	
	static List<Friend> list;
	static {
		list = new ArrayList<>();
		List <String> lst1=List.of("Gaming","Drawwing");
		List <String> lst2=List.of("Devlopment","Drawwing","Gaming");
		
	
		
		list.add(new Friend(1,"Tina",lst1,"22334411","tina@gmail.com",LocalDate.of(2002, 6, 12),"Jaipur"));
		list.add(new Friend(2,"Vaibhav",lst2,"55667788","vaibhav@gmail.com",LocalDate.of(2000, 10, 12),"Udgir"));
		
	}
	@Override
	public List<Friend> display() {
		
		return list;
	}
	@Override
	public Friend SerachId(int id) {
		for(Friend f:list) {
			if(f.getId()==id) {
				return f;
			}
		}
		return null;
	}
	@Override
	public List<Friend> SearchName(String name) {
		List<Friend> l = new ArrayList<>();
		for(Friend f:list) {
			if(f.getLastname().equals(name)) {
				l.add(f);
			}
		}
		if(l.isEmpty()) {
			return null;
		}
		return l;
	}
	@Override
	public List<Friend> displayH(String h) {
		List<Friend> lst = new ArrayList<>();
		for(Friend s:list) {
			for(String hb:s.getHobbies()) {
			if(hb.equals(h)) {
			lst.add(s);
		}
			
			}
			return lst;
		}
		return null;
	}

}
