package com.demo.service;

import java.util.List;

import com.demo.bean.Friend;


public interface IFriendService {
	
	List<Friend> displayAll();

	Friend SearchById(int id);

	List<Friend> SearchByName(String name);

	List<Friend> displayHobbie(String h);

}
