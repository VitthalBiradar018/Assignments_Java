package com.demo.service;

import java.util.List;

import com.demo.bean.Friend;
import com.demo.dao.FriendDao;

public class FriendService implements IFriendService{
	
	private FriendDao fdao;
	
	public FriendService(){
		this.fdao=new FriendDao();
	}
	@Override
	public List<Friend> displayAll() {
		return fdao.display();
	}
	@Override
	public Friend SearchById(int id) {
		return fdao.SerachId(id);
	}
	@Override
	public List<Friend> SearchByName(String name) {
		return fdao.SearchName(name);
	}
	@Override
	public List<Friend> displayHobbie(String h) {
		return fdao.displayH(h);
	}

}
