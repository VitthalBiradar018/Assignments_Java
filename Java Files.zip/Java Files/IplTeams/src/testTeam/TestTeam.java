package testTeam;
import java.util.Scanner;
import service.*;
/*Write a program to store information about IPL teams in ArrayList
Create Team class to store teamid, tname, coachname, and list of players.
and perform following operations
1. add new Team
2. delete a team
3. delete a player from team(accept player id to delete)
4. display all batsman
5. display all player with a speciality(accept speciality from user)
6. add a new player in a team
7. modify coach of a team
8. exi*/
public class TestTeam {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		TeamService ts = new TeamServiceImpl();
		while(true) {
		System.out.println("Enter your choice:");
		System.out.println("1.add \n 2.delete \n 3.delete Player \n 4.displayAll batsman \n 5.add new Player\n 6.modify coach");
	int choice = sc.nextInt();
		switch(choice) {
		case 1:
			boolean status = ts.addNew();
			if(status) {
				System.out.println("Team added Sucessfully:");
				
			}else {
				System.out.println("Adding unsucessfull:");
			}
			break;
		case 2:
			System.out.println("Enter teamid to remove Team:");
			int tid = sc.nextInt();
			boolean st=ts.removeT(tid);
			if(st) {
				System.out.println("Removed sucessfull;");
			}
			else {
				System.out.println("error");
			}
			break;
		case 3:
			System.out.println("Enter teamid to remove player:");
			int id = sc.nextInt();
			System.out.println("Enter Player to be removed");
			String plr = sc.next();
			boolean sts=ts.removeP(id,plr);
			if(sts) {
				System.out.println("Removed sucessfull;");
			}
			else {
				System.out.println("error");
			}
			break;
		case 4:
			ts.displayAll();
			break;
		case 5:
			System.out.println("Enter teamid to Modify Coach:");
			 tid = sc.nextInt();
			 System.out.println("Enter player name to add:");
			 String pname = sc.next();
			 boolean s = ts.addP(tid,pname);
			 if(s) {
				 System.out.println("Player added sucessfull");
			 }
			 else {
				 System.out.println("error");
			 }
			break;
		case 6:
			System.out.println("Enter teamid to Modify Coach:");
			 tid = sc.nextInt();
			System.out.println("Enter modifed coachname:");
			String coach = sc.next();
			boolean b = ts.addCoach(tid,coach);
			if(b) {
				System.out.println("Modified Sucessfull:");
			}
			else {
				System.out.println("error");
			}
			break;
		}
		System.out.println("you want to repeat: y/n");
		String s = sc.next();
		if(s.equals("n")) {
			break;
			
		}
		}
	
	}
	

}
