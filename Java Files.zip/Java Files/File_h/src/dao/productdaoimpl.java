package dao;

import java.util.ArrayList;
import java.util.List;
import bean.Product;


public class productdaoimpl {
 
	List<Product> lst = new ArrayList<>();
	
	
	boolean addf(Product p )
	{
		return lst.add(p);
	}
}
