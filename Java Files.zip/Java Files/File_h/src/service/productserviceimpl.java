package service;
import dao.productdao;
import bean.Product;
import java.util.Scanner;
public class productserviceimpl {

	private productdao pdao;
	Scanner sc = new Scanner(System.in);
	
	public boolean addfile() {
		System.out.println("Enter id");
		int id = sc.nextInt();
		System.out.println("enter name");
		String name = sc.next();
		
		Product p = new Product(id,name);
		return pdao.addf(p);
		
	}

}
