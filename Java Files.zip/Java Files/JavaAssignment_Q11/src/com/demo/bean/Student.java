package com.demo.bean;

import java.util.Objects;

public class Student {
	private int stdId;
	private String name;
	private String degree;
	private String email;
	
	
	

	public Student(int stdId, String name, String degree, String email) {
		super();
		this.stdId = stdId;
		this.name = name;
		this.degree = degree;
		this.email = email;
	}



	public Student(int stdId) {
		super();
		this.stdId = stdId;
	}



	public Student() {
		super();
	}
	


	public int getStdId() {
		return stdId;
	}



	public void setStdId(int stdId) {
		this.stdId = stdId;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getDegree() {
		return degree;
	}



	public void setDegree(String degree) {
		this.degree = degree;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	@Override
	public String toString() {
		return "Student [stdId=" + stdId + ", name=" + name + ", degree=" + degree + ", email=" + email + "]";
	}



	@Override
	public boolean equals(Object obj) {
		Student s=(Student) obj;
	
		return stdId == s.stdId;
	}
}
