package com.demo.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import com.demo.bean.Student;

public class StudentDao implements IStudentDao {
	
	static ArrayList<Student> lst;
	
	static {
		lst=new ArrayList<>();
		lst.add(new Student(101,"Rajesh","Btech","rajesh@gmail.com"));
		lst.add(new Student(102,"Amol","Btech","amol@gmail.com"));
		lst.add(new Student(103,"Kedar","Bcom","kedar@gmail.com"));
	}
	

	@Override
	public boolean addStudent(Student obj) {
		return lst.add(obj);
	}

	@Override
	public ArrayList<Student> getStudents() {
		
		return  lst;
	}




	
	public void writeFile() {
		try(BufferedWriter bw=new BufferedWriter(new FileWriter("test.txt"));){
			for(Student ob:lst) {
				bw.write(ob.getStdId()+","+ob.getName()+","+ob.getDegree()+","+ob.getEmail()+"\n");
			}
			System.out.println("Done");
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Not Done");
		}
	}





}
