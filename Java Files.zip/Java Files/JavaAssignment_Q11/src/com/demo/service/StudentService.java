package com.demo.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.demo.dao.*;
import com.demo.bean.Student;


public class StudentService implements IStudentService{ 
	
	
	StudentDao s2 = new StudentDao();
	
	public Student getStudentObj() {
		Scanner sc = new Scanner (System.in);
		
		System.out.println("enter id" );
		int Stdid = sc.nextInt();
		
		sc.nextLine();
		System.out.println("enter name" );
		String name = sc.next();
		
		
		System.out.println("enter degree" );
		String degree = sc.next();
		
		System.out.println("enter email" );
		String email = sc.next();
		

		Student s1=new Student(Stdid,name,degree,email);
	
		return s1;
	}
	
	

	@Override
	public boolean setStudent(Student obj) {
		
		return s2.addStudent(obj);
	}


	@Override
	public ArrayList<Student> getStudentData() {
		return s2.getStudents();
	}



	@Override
	public void writeFile() {
		s2.writeFile();
	}

	

	
	
}
