package test;
import dao.ReadDao;
import java.util.List;
public class ReadTest {

	public static void main(String[] args) {
		ReadDao rd = new ReadDao();
		List<String> lt  = rd.displayAll();
		System.out.println(lt);

	}

}
