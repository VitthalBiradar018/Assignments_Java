package com.demo.bean;

public class car {
private String name;
private String model;
private int cc;


public int getCc() {
	return cc;
}
public void setCc(int cc) {
	this.cc = cc;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getModel() {
	return model;
}
public void setModel(String model) {
	this.model = model;
}

public car(String name, String model, int cc) {
	super();
	this.name = name;
	this.model = model;
	this.cc = cc;
}
public car() {
	super();
}
@Override
public String toString() {
	return "car [name=" + name + ", model=" + model + ", cc=" + cc + "]";
}



}
