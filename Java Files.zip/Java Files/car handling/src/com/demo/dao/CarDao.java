package com.demo.dao;

import com.demo.bean.car;

public interface CarDao {


	void carw(car c);

}
