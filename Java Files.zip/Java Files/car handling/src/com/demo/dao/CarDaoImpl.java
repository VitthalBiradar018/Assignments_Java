package com.demo.dao;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

import com.demo.bean.car;s

public class CarDaoImpl implements CarDao{
			List<car> lcar = new ArrayList<>();
	@Override
	public void carw(car c) {
		try (BufferedWriter bw = new BufferedWriter(new FileWriter("CARS.txt"));){
			for(car c1 : lcar) {
			bw.write(lcar.add(new car(c1.getName(),c1.getModel(),c1.getCc())));
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
	
}
