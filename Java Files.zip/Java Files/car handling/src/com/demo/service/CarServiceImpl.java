package com.demo.service;

import java.util.Scanner;

import com.demo.bean.car;
import com.demo.dao.CarDao;
import com.demo.dao.CarDaoImpl;

public class CarServiceImpl implements CarService {

	Scanner sc = new Scanner(System.in);
	
	CarDao cd = new CarDaoImpl();
	@Override
	public void carwrite() {
		System.out.println("Enter Brand : ");
		String nm = sc.next();
		System.out.println("Enter model : " );
		String model = sc.next();
		System.out.println("Enter Cubic capicity (CC) : ");
		int cc = sc.nextInt();
		
		car c = new car(nm,model,cc);
		cd.carw(c);
		
	}

}
