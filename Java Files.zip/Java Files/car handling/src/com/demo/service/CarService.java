package com.demo.service;

public interface CarService {

	void carwrite();

}
