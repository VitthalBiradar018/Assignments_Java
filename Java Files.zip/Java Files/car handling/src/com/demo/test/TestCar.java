package com.demo.test;

import com.demo.service.CarService;
import com.demo.service.CarServiceImpl;

public abstract class TestCar {

	public static void main(String[] args) {
    
		CarService  cs = new CarServiceImpl();
		
		cs.carwrite();
		
	}

}
