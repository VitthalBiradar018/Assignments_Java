package com.demo.test;

import java.util.Scanner;

import com.demo.service.*;

public class TestEmployee {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		IEmployeeService obj=new EmployeeService();
		
		System.out.println("1. Add Employee, 2. Display Employee");
		int choice =sc.nextInt();
		
		switch(choice) {
			case 1:
				obj.addEmp();
				break;
			case 2:
				obj.displayEmp();
				break;
		}
		
	}
}
