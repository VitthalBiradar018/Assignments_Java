package com.demo.dao;

import java.util.Set;
import java.util.ArrayList;
import java.util.HashSet;

import com.demo.bean.Employee;

public class EmployeeDao implements IEmployeeDao {
	static Set<Employee> pset ;
	
	static {
		pset = new HashSet<>();
		pset.add(new Employee(101,"Raj","Sales","Manager",55000.0f));
		pset.add(new Employee(102,"Raj","HR","Manager",45000.0f));
		pset.add(new Employee(103,"Raj","IT","Developer",35000.0f));
	}

	@Override
	public void addData(Employee emp) {
		
		
		pset.add(emp);
		
	}

	@Override
	public HashSet<Employee> getData() {
		return (HashSet<Employee>) pset;
	}
	
	
	

}
