package com.demo.dao;

import java.util.ArrayList;
import java.util.HashSet;

import com.demo.bean.Employee;

public interface IEmployeeDao {

	void addData(Employee emp);

	HashSet<Employee> getData();

}
