package com.demo.service;

public interface IEmployeeService {

	void addEmp();

	void displayEmp();

}
