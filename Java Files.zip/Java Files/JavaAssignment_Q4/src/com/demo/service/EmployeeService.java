package com.demo.service;
import java.util.Scanner;

import com.demo.dao.*;
import com.demo.bean.*;

public class EmployeeService implements IEmployeeService {
	IEmployeeDao obj=new EmployeeDao();
	@Override
	public void addEmp() {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id :");
		int id=sc.nextInt();
		System.out.println("Enter Name :");
		String name=sc.next();
		System.out.println("Enter Sal :");
		float sal=sc.nextFloat();
		System.out.println("Enter Dept :");
		String dept=sc.next();
		System.out.println("Enter Desig :");
		String desg=sc.next();
		
		Employee emp=new Employee(id,name,desg,dept,sal);
		
		obj.addData(emp);
		
	}

	@Override
	public void displayEmp() {
		
		obj.getData().stream().forEach(obj->System.out.println(obj));
	}
	
	
	

}
