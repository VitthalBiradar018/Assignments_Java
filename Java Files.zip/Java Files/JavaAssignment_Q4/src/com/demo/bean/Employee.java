package com.demo.bean;

import java.time.LocalDate;
import java.util.Objects;

public class Employee {
	private int id;
	private String name;
	private String  dept,desig;
	private float sal;
	public Employee(int id, String name, String dept, String desig,float sal) {
		super();
		this.id = id;
		this.name = name;
		this.dept = dept;
		this.desig = desig;
		this.sal=sal;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public float getSal() {
		return sal;
	}
	public void setSal(float sal) {
		this.sal = sal;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getDesig() {
		return desig;
	}
	public void setDesig(String desig) {
		this.desig = desig;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ",\n name=" + name +  ",\n dept=" + dept
				+ ",\n desig=" + desig + " Salary= " + sal +" ]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
	@Override
	public boolean equals(Object obj) {

		Employee other = (Employee) obj;
		return id == other.id;
	}
	
	

}
