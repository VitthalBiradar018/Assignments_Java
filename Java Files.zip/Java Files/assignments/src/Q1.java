
public class Q1 {

	public static void main(String[] args) {
		System.out.println("No of arguments "+ args.length);
		int s=0,cnt,num;
		for(int i=0;i<args.length;i++) {
			cnt=0;
			num=0;
			num=Integer.parseInt(args[i]);
			for(int j=1;j<=num;j++) {
				if(num%j==0) {
					cnt++;
				}
			}
			System.out.println("num :"+cnt);
			if(cnt==2) {
				for(int k=1;k<=10;k++) {
					System.out.println(num*k);
				}
				
			}
			else {
				s=num/10;
				System.out.println("Result ="+s);
			}
		}
	}

}
