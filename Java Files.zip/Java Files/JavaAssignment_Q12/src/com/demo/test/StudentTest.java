package com.demo.test;
import java.util.List;
import java.util.Scanner;

import com.demo.bean.Student;
import com.demo.service.*;

public class StudentTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// Create a ProductService class object
		IStudentService sservice = new StudentService();
		
		int choice = 0;
		do {
			System.out.println("1. Add New Student\n2. Display All\n");
			System.out.println("3. Exit \nChoice:");
			
			choice = sc.nextInt();
			switch(choice) {
			case 1:
				boolean status = sservice.setStudent(sservice.getStudentObj());
				if(status) {
					System.out.println("Added Successfully");
				}
				else {
					System.out.println("Error Occurred");
				}
				break;
			case 2:
				List<Student> slist = sservice.getStudentData();
				slist.stream().forEach(ob->System.out.println(ob));
				
				break;
			
			case 3:
				sc.close();
				sservice.writeFile();
				System.out.println("Thank you for Visiting!!!");
				break;
			default :
				System.out.println("Invalid Choice");
				break;
			}
			
		} while(choice!=3);

	}

}
