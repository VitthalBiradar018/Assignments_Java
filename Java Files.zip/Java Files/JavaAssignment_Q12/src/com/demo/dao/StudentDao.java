package com.demo.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import com.demo.bean.Student;

public class StudentDao implements IStudentDao {
	
	static ArrayList<String> lst;
	
	static {
		lst=new ArrayList<>();
	}
	

	@Override
	public boolean addStudent(String obj) {
		return lst.add(obj);
	}

	@Override
	public ArrayList<String> getStudents() {
		
		return  lst;
	}

	public void writeFile() {
		try(BufferedWriter bw=new BufferedWriter(new FileWriter("test.txt"));){
			for(String ob:lst) {
				bw.write (ob+"\n");
			}
			System.out.println("Done");
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Not Done");
		}
	}
	
	public void readFile() {
		try(BufferedReader br=new BufferedReader(new FileReader("test.txt"));){
			String s=br.readLine();
			while(s!=null) {
				System.out.println(s);
				s=br.readLine();
				lst.add(s);
				
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}




}
