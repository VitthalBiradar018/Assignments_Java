package com.demo.threads;

import java.util.concurrent.Callable;

public class AdditionTask implements Callable<Integer> {
	 private final int num1;
	    private final int num2;
	    private final int num3;

	    public AdditionTask(int num1, int num2, int num3) {
	        this.num1 = num1;
	        this.num2 = num2;
	        this.num3 = num3;
	    }

	    @Override
	    public Integer call() {
	        return num1 + num2 + num3;
	    }
}

