package test;
import service.ProductService;
import service.ProductServiceImpl;
import java.util.Scanner;

public class TestProduct {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in); 
		ProductService ps = new ProductServiceImpl();
		System.out.println("Enter Choice ");
		System.out.println(" 1.Display items \n 2.ADD item \n 3. serach by id \n 4. serach by name");
		int ch = sc.nextInt();
		switch(ch) {
		case 1 :
			ps.displayAll();
			break;
		
		case 2 :
			
			boolean status = ps.addItem();
			 break;
		}
				
	}

}
