package beans;

import java.time.LocalDate;

public class Product {

	private int id;
	private String name;
	private LocalDate ex_date;
	public Product(int id, String name, LocalDate ex_date) {
		super();
		this.id = id;
		this.name = name;
		this.ex_date = ex_date;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDate getEx_date() {
		return ex_date;
	}
	public void setEx_date(LocalDate ex_date) {
		this.ex_date = ex_date;
	}
	@Override
	public String toString() {
		return "id=" + id + "\n name=" + name + "\n ex_date=" + ex_date ;
	}
	
	
}
