package service;
import beans.Product;
import java.util.Scanner;
import dao.productDao;
import dao.productDaoImpl;
public class ProductServiceImpl implements ProductService {

	
	Scanner sc = new Scanner(System.in);
	
	private productDao sd;
	public ProductServiceImpl() {
		this.sd = new productDaoImpl();
	}
	@Override
	public void displayAll() {
		sd.display();
		
	}
	@Override
	public boolean addItem() {
	
		
		
		return false;
	}
}
