 
public class Demat extends Account {

	public Demat(int id, String name, double balance) {
		super(id, name, balance);
		// TODO Auto-generated constructor stub
	}
	
	public String ToString() {
		return super.toString();
	}


}
