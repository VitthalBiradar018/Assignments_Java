
public class Saving extends Account{

	public Saving(int id, String name, double balance) {
		super(id, name, balance);
	
		
	}
	
	public void checkbal() {
		System.out.println("Availble Balance :- " + getBalance());
	}
	

}
