package DAO;

import bean.Account;

public interface AccData {

	boolean create(Account a);
	void showData();
	double getB(int i);
	void setB(double amt,int i);
	void widraw(double amt1, int i2);
	
}
