import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class StudentService {

	public static void CreateStudentData(Student[] arr) {
		Scanner sc=new Scanner(System.in);
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		
		for(int i=0;i<arr.length;i++) {
			System.out.println("enter Id : ");
			int Id=sc.nextInt();  
			System.out.println("enter Name : ");
			sc.nextLine(); 
			String Name=sc.nextLine();
			System.out.println("enter Mark1 : ");
			int Mark1=sc.nextInt();
			System.out.println("enter Mark2 : ");
			int Mark2=sc.nextInt();
			System.out.println("enter Mark3 : ");
			int Mark3=sc.nextInt();
			System.out.println("enter date of birth(dd/MM/yyyy)");
			String dt=sc.next();
			try {
				Date dt1=sdf.parse(dt);
				//create object
				arr[i]=new Student(Id, Name, dt1, Mark1, Mark2, Mark3);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
		}
	}

	public static void displayStudentData(Student[] arr) {
		for(int i=0;i<arr.length;i++) {
			arr[i].getData();
		}
	}
	
	
	
	public static void SearchStudentId(Student[] arr)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter SId For Search : ");
		int SId =sc.nextInt();
		for(int i=0;i<arr.length;i++)
		{
			if(SId==arr[i].getId())
			{
				arr[i].getData();
			}
		}
		
	}

	public static void SearchStudentName(Student[] arr)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter SName For Search : ");
		String SName =sc.next();
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i].getName().equalsIgnoreCase(SName))
			{
				arr[i].getData();
			}
		}
	}
	public static void SearchAbove75Percent(Student[] arr)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter SPercentage For Search : ");
		double SPercentage =sc.nextInt();
		for(int i=0;i<arr.length;i++)
		{
			if(SPercentage<=arr[i].getPercentage())
			{
				arr[i].getData();
			}
		}
		
		
	}
	
}