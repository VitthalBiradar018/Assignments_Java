import java.util.Date;

public class Student {
	
	private int Id;
	private String Name;
	private Date JoinDate;
	private int Mark1;
	private int Mark2;
	private int Mark3;
	private double Percentage;
	
	 public Student(int Id,String Name,Date dob,int Mark1,int Mark2,int Mark3){
	        this.Id=Id;
			this.Name=Name;
			this.Mark1=Mark1;
			this.Mark2=Mark2;
			this.Mark3=Mark3;
			JoinDate=dob;
	   } 
	
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Date getJoinDate() {
		return JoinDate;
	}
	public void setJoinDate(Date joinDate) {
		JoinDate = joinDate;
	}
	public int getMark1() {
		return Mark1;
	}
	public void setMark1(int mark1) {
		Mark1 = mark1;
	}
	public int getMark2() {
		return Mark2;
	}
	public void setMark2(int mark2) {
		Mark2 = mark2;
	}
	public int getMark3() {
		return Mark3;
	}
	public void setMark3(int mark3) {
		Mark3 = mark3;
	}
	
	
	public double getPercentage() {
		Percentage = ((Mark1+Mark2+Mark3)/3);
		return Percentage;
	}
	
	
	public void getData() {
		System.out.println("Id :"+Id+"\tName :"+Name+"\tJoiningDate :"+JoinDate);
		System.out.println("Percentage :"+getPercentage());
	}
	
	
}
