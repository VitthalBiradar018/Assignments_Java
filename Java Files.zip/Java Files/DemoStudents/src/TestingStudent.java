import java.util.Scanner;
public class TestingStudent {

	public static void main(String[] args)
	{
			
		Scanner sc = new Scanner(System.in);
			Student[] arr=new Student[2];
			StudentService.CreateStudentData(arr);
			StudentService.displayStudentData(arr);
			String ch=sc.next();
			do {
			System.out.println("Enter Choice 1 SearchStudentId , 2 SearchStudentName , 3 SearchAbove75Percent ");
			int Choice=sc.nextInt();
			switch(Choice)
			{
			case 1:
				StudentService.SearchStudentId(arr);
				break;
			case 2:
				StudentService.SearchStudentName(arr);
				break;
			case 3:
				StudentService.SearchAbove75Percent(arr);
				break;
			default:
				break;
			}
			
			}while(ch != "y");
	}

}
