package test;

import java.util.Scanner;

import bean.operations;

public class testThread {
	public static void main(String[] args) {
		
	
	operations op =  new operations();
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter number ");
	int num = sc.nextInt();
	op.table(num);
	
	
	
	}
}
