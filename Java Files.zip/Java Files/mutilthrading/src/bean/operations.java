package bean;

public class operations {

	public void table(int x) {
		int total = 1;
		for (int i = 1 ; i<=10 ; i++) {
			total = i*x;
			System.out.println(i + " * "+ x + " = " + total);
		}
		
	}
	
	public int factorial (int y) {
		int fact = 1;
		for(int i = 1; i<=y ; i++ ) {
			fact = i*fact;
			
		}
		return fact;
	}
}
