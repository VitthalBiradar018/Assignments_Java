package dao;

import java.util.List;

import beans.Student;

public interface StudentDao {

	boolean addL(Student s);

	boolean addF();

	List<String> readf();

}
