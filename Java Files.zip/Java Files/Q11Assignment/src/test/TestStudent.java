package test;

import java.util.List;
import java.util.Scanner;

import service.StudentService;
import service.StudentServiceImpl;

public class TestStudent {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		StudentService sts = new StudentServiceImpl();
		int choice;
		do {
			System.out.println("1.add in List\n 3.exit \n 2. Read");
			choice=sc.nextInt();
			switch(choice) {
			case 1:
				boolean status = sts.addInList();
				if(status) {
					System.out.println("added Sucessfully");
				}
				else {
					System.out.println("Error");
				}
				break;
			case 3:
				boolean st = sts.addInFile();
				if(st) {
					System.out.println("added Sucessfully");
				}
				else {
					System.out.println("Error");
				}
				break;
			case 2 :
				//boolean ya = sts.readfile();
				List<String> s = sts.readfile();
				System.out.println(s);
				break;
			default :
				System.out.println("Invalid Choice");
				break;
			}
		}while(choice!=3);

	}

}
