import java.util.Scanner;
public class ArrayService {

	
	public static void addnewdata(int[][] arr2)
	{
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<arr2.length;i++)
		{
			for(int j=0;j<arr2[i].length;j++)
			{
				System.out.println("enter number at row "+i+"Column"+j);
				arr2[i][j]=sc.nextInt();
			}
		}
	}

	public static void displaydata(int[][] arr2) 
	{
		for(int i=0;i<arr2.length;i++)
		{
			for(int j=0;j<arr2[i].length;j++)
			{
				System.out.print(arr2[i][j]);				
			}
		}
	}
	
	public static void transposeofmatrix(int[][] arr2)
	{
		for(int i =0;i<arr2.length;i++)
		{
			for(int j =0;j<arr2.length;j++)
			{
				System.out.println(arr2[j][i]);
			}
		}
	}
	public static void rowwisesum(int[][] arr2)
	{
		int[] sum=new int[3]; 
		
		for(int i =0;i<arr2.length;i++)
		{
			for(int j =0;j<arr2.length;j++)
			{
				sum[i]=sum[i]+arr2[j][i];
			
			}
			System.out.println(sum[i]);
		}
		
	}
	public static void columnwisesum(int[][] arr2)
	{
		int[] sum=new int[3]; 
		
		for(int i =0;i<arr2.length;i++)
		{
			for(int j =0;j<arr2.length;j++)
			{
				sum[i]=sum[i]+arr2[i][j];
			
			}
			System.out.println(sum[i]);
		}
		
	}

	public static void matrixmultiplication(int[][] arr2) {
		// TODO Auto-generated method stub
		
	}
}
