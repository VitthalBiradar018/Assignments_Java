package service;

import java.time.LocalDate;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import beans.Product;
import dao.FileDao;
import dao.FileDaoImpl;

public class FileServiceImpl implements FileService {
private FileDao fdao;
public FileServiceImpl() {
	fdao = new FileDaoImpl();
}
Scanner sc = new Scanner(System.in);
	@Override
	public boolean addInList() {
		
		System.out.println("Enter Pid");
		int pid = sc.nextInt();
		System.out.println("Enter Product Name");
		String nm = sc.next();
		System.out.println("Enter Price");
		int price = sc.nextInt();
		System.out.println("Enter Expiry Date in format (dd/MM/yyyy)");
		String expdt = sc.next();
		LocalDate ldt = LocalDate.parse(expdt,DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		
		Product p = new Product(pid, nm,price, ldt);
		return fdao.addAll(p);
		
	}
	@Override
	public void addInFile() {
		fdao.addFile();
		
	}
	@Override
	public List<Product> readFile() {
		return fdao.readInFile();
		
	}
	@Override
	public boolean removeF(int id) {
		return fdao.removeFile(id);
	}
	@Override
	public boolean updateF(int id) {
		System.out.println("Enter updated name:");
		String name = sc.next();
		System.out.println("Enter updated price:");
		int price = sc.nextInt();
		return fdao.updateInF(id,name,price);
	}
	@Override
	public List<Product> displayAll() {
		return fdao.display();
	}
	@Override
	public Product getById(int pid) {
	return fdao.searchById(pid);
	}
	@Override
	public void appendFile() {
		fdao.sppendInFile();
	}


}
