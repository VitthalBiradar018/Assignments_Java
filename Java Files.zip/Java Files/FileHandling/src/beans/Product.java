package beans;


import java.io.Serializable;
import java.time.LocalDate;



public class Product implements Serializable {
	private int id;
	private String name;
	private int price;
	transient private LocalDate expDate;
	public Product(int id, String name, int price, LocalDate expDate) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.expDate = expDate;
	}
	
	
	public Product() {
		super();
	}
	public Product(int id) {
		super();
		this.id = id;
	}
	@Override
	public boolean equals(Object obj) {
		Product other=((Product)obj);
		System.out.println("in Product equals method"+this.id+"---->"+other.id);
		return this.id==other.id;
	}
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public LocalDate getExpDate() {
		return expDate;
	}
	public void setExpDate(LocalDate expDate) {
		this.expDate = expDate;
	}
	
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + ", expDate=" + expDate + "]";
	}
	   
	
	
}
