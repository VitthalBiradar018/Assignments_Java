package dao;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import objectclass.MyObjectStream;
import beans.Product;

public class FileDaoImpl implements FileDao {
	static List<Product> plist ;
	static{
		plist=new ArrayList<>();
	}
	@Override
	public boolean addAll(Product p) {
	
				return plist.add(p);		
		
	}
	@Override
	public void addFile() {
		try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("My.txt"));){
			for(Product p : plist) {
				oos.writeObject(p);
				System.out.println("Object added Sucessfully in File");
			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@Override
	public List<Product> readInFile() {
		List<Product> lst = new ArrayList<>();
		File f = new File("My.txt");
		if(f.exists()) {
		try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))){
			while(true) {
				Product p = (Product)ois.readObject();
				lst.add(p);
			}
			
			
		}catch(EOFException e) {
			System.out.println("Reached End Of Line");
			System.out.println("Length: " + plist.size());
		}
		
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		return lst;
		
	}
	public Product searchById(int id) {
		int pos = plist.indexOf(new Product(id));
		if(pos==-1) {
			return null;
		} else {
			return plist.get(pos);
		}
	}
	@Override
	public boolean removeFile(int id) {
		return plist.remove(new Product(id));
		
		}
	@Override
	public boolean updateInF(int id,String name,int price) {

		Product p = searchById(id);
		if(p!=null) {
			p.setName(name);
			p.setPrice(price);
			return true;
		}
		return false;
	}
	@Override
	public List<Product> display() {
		
		return plist;
	}
	@Override
	public void sppendInFile() {
		File f = new File("My.txt");
		if(f.exists()) {
		try(MyObjectStream oos = new MyObjectStream(new FileOutputStream(f,true));){
			for(Product p : plist) {
				oos.writeObject(p);
				System.out.println("Object added Sucessfully in File");
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}else {
			try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("My.txt"));){
				for(Product p : plist) {
					oos.writeObject(p);
					System.out.println("Object added Sucessfully in File");
				}
				
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

	


