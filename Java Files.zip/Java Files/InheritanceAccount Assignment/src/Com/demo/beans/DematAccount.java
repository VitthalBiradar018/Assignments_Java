package Com.demo.beans;

public class DematAccount extends Account {
	public DematAccount(int accountNo,String name,double balance)
	{
		super(accountNo,name,balance);
	}
	
	public double Commision()
	{
		return getBalance()*0.01;
	}

	@Override
	public double CalculateInterest() {
		return getBalance()*0.03;
	}

	@Override
	public String toString() {
		return super.toString()+"DematAccount Interest is "+" "+ CalculateInterest()+"\n"+"Commision is :"+Commision();

	}
	
	

}
