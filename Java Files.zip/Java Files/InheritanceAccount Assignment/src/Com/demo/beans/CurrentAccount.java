package Com.demo.beans;

public class CurrentAccount extends Account {
	static int transaction=0;
	public CurrentAccount(int accountNo, String name, double balance) {
		super(accountNo,name,balance);
		transaction++;
	}
	
	public int noOfTransaction()
	{
		return transaction;
	}

	public double CalculateInterest()
	{
		return getBalance()*0.03;
	}

	@Override
	public String toString() {
		return super.toString()+"CurrentAccount Interest is "+" "+CalculateInterest()+"\n"+"Your Transaction Is"+noOfTransaction();
	}
	

}
