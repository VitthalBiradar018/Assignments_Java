package Com.demo.beans;

public  class SavingAccount extends Account {
	
	static int transaction=0;
	public SavingAccount(int accountNo, String name, double balance) {
		super(accountNo,name,balance);
		
	}
	
	public double CheckBalance()
	{
		return getBalance();
	}
	
	public double CalculateInterest()
	{
		return getBalance()*0.01;
	}

	@Override
	public String toString() {
		return super.toString()+"SavingAccount Interest is "+" "+ CalculateInterest()+"\n"+"Your Balance Is :"+CheckBalance();
	}
	
}
