package Com.demo.test;
import Com.demo.beans.*;
import java.util.Scanner;
public class TestAccount {

	public static void main(String [] args) {
	while(true)
		
	{   	Scanner sc = new Scanner(System.in);
		System.out.println("1. Saving Account , 2. Current Account , 3. Demat Account");
		System.out.println("Enter Your Account Type : ");
		int Choice = sc.nextInt();
		
		Account a = null;
		
		switch(Choice)
		{
		case 1:
			a= new SavingAccount(1,"Rushi",100000.50);
			break;
		case 2:
			a= new CurrentAccount(2,"Vaibhav",200000.50);
			break;
		case 3:
			a= new DematAccount(3,"Ravi",300000.50);
			break;
		default:
			System.out.println("Choice Correct Option ");
				
		}
		System.out.println(a);
	}
}
}
