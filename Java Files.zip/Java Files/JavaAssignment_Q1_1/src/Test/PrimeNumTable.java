package Test;

import Service.TestService;

public class PrimeNumTable {

	public static void main(String[] args) {
		
		TestService.showResult();
	}

}
