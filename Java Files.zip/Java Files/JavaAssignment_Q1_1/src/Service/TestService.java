package Service;
import java.util.Scanner;
public class TestService {
	
	public static boolean checkPrime(int a) {
		for(int i=2;i<a;i++) {
			if(a%i==0) {
				return false;
			}
		}		
		return true;
	}

	public static int getInput() {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Number :");
		int num=sc.nextInt();
		
		return num;
	}
	
	public static void getTable(int a) {
		for(int i=1;i<=10;i++) {
			System.out.println(a+" x "+i+" ="+(a*i));
		}
	}
	
	public static void showResult() {
		for(int i=0;i<3;i++) {
			
			int num=getInput();
			
			if(checkPrime(num)) {
				getTable(num);
			}
			else {
				System.out.println("the Number is not Prime so :"+num+"/10="+num/10);
			}	
		}	
	}
}
