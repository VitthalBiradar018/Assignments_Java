package service;

import java.util.List;

import beans.Friend;

public interface FriendService {

	List<Friend> displayAll();

	Friend SearchById(int id);

	List<Friend> SearchByName(String name);

	List<Friend> displayHobbie(String h);

}
