package dao;

import java.util.List;
import java.time.LocalDate;
import java.util.ArrayList;

import beans.Friend;

public class FriendDaoImpl implements FriendDao{
	static List<Friend> list;
	static {
		list = new ArrayList<>();
		List <String> lst=List.of("Sports","Gaming");
		List <String> lst1=List.of("Gaming","Drawwing");
		List <String> lst2=List.of("Devlopment","Drawwing","Gaming");
		List <String> lst3=List.of("Swimming","Drawwing");
		
	
		
		list.add(new Friend(1,"Vitthal",lst,"12345","vitthalb125@gmail.com",LocalDate.of(2002, 6, 12),"Nanded"));
		list.add(new Friend(2,"Vedant",lst1,"23890","vedant234@gmail.com",LocalDate.of(2001, 8, 20),"Kolhapur"));
		list.add(new Friend(3,"Vaibhav",lst2,"788899","vaibhav223@gmail.com",LocalDate.of(2001, 10, 12),"Udgir"));
		list.add(new Friend(4,"Rushi",lst3,"444353","Rushi2343@gmail.com",LocalDate.of(2001, 8, 23),"Karad"));
		
	}
	@Override
	public List<Friend> display() {
		
		return list;
	}
	@Override
	public Friend SerachId(int id) {
		for(Friend f:list) {
			if(f.getId()==id) {
				return f;
			}
		}
		return null;
	}
	@Override
	public List<Friend> SearchName(String name) {
		List<Friend> l = new ArrayList<>();
		for(Friend f:list) {
			if(f.getLastname().equals(name)) {
				l.add(f);
			}
		}
		if(l.isEmpty()) {
			return null;
		}
		return l;
	}
	@Override
	public List<Friend> displayH(String h) {
		List<Friend> lst = new ArrayList<>();
		for(Friend s:list) {
			for(String hb:s.getHobbies()) {
			if(hb.equals(h)) {
			lst.add(s);
		}
			
			}
			return lst;
		}
		return null;
	}
	}	
	
	

