package beans;

import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;



public class Friend {
 private int id;
 private String lastname;
 private List<String> hobbie;
 private String mobno;
 private String email;
 private LocalDate bdate;
 
private String address;

public Friend(int id, String lastname, List<String> hobbies, String mobno, String email, LocalDate bdate, String address) {
	super();
	this.id = id;
	this.lastname = lastname;
	this.hobbie = hobbies;
	this.mobno = mobno;
	this.email = email;
	this.bdate = bdate;
	this.address = address;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getLastname() {
	return lastname;
}

public void setLastname(String lastname) {
	this.lastname = lastname;
}

public List<String> getHobbies() {
	return hobbie;
}

public void setHobbies(List<String> hobbies) {
	this.hobbie = hobbies;
}

public String getMobno() {
	return mobno;
}

public void setMobno(String mobno) {
	this.mobno = mobno;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public LocalDate getBdate() {
	return bdate;
}

public void setBdate(LocalDate bdate) {
	this.bdate = bdate;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}
//public void displayHobbis(hobbies) {
//	for(String s:list) {
//		System.out.println(s);
//	}
//}
@Override
public String toString() {
	return "Friend [id=" + id + ", lastname=" + lastname + ", hobbies=" + hobbie + ", mobno=" + mobno + ", email="
			+ email + ", bdate=" + bdate + ", address=" + address + "]";
}



}
