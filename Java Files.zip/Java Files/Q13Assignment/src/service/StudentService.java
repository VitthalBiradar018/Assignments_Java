package service;

public interface StudentService {

	boolean addInList();

	boolean addInFile();

}
