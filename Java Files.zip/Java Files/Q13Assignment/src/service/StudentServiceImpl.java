package service;

import java.util.Scanner;
import beans.Student;
import dao.StudentDao;
import dao.StudentDaoIml;
public class StudentServiceImpl implements StudentService {
	private StudentDao stdao;
	public StudentServiceImpl() {
		stdao = new StudentDaoIml();
	}
	@Override
	public boolean addInList() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Student id:");
		int id = sc.nextInt();
		System.out.println("Enter Student Name");
		String name = sc.next();
		System.out.println("Enter Student email:");
		String email = sc.next();
		System.out.println("Enter degree of Student:");
		String degree = sc.next();
		
		Student s = new Student(id,name,email,degree);
		
		return stdao.addL(s);
	}
	@Override
	public boolean addInFile() {
		return stdao.addF();
	}
}
