package test;

import java.util.List;
import dao.ReadDao;
import java.util.Scanner;

import beans.Student;
import service.StudentService;
import service.StudentServiceImpl;

public class TestStudent {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		StudentService sts = new StudentServiceImpl();
		int choice;
		do {
			System.out.println("1.add in List\n 2.exit\n 3.read");
			choice=sc.nextInt();
			switch(choice) {
			case 1:
				boolean status = sts.addInList();
				if(status) {
					System.out.println("added Sucessfully");
				}
				else {
					System.out.println("Error");
				}
				break;
			case 2:
				boolean st = sts.addInFile();
				if(st) {
					System.out.println("added Sucessfully");
				}
				else {
					System.out.println("Error");
				}
				break;
			case 3:
				ReadDao rd = new ReadDao();
				List<Student> lt = rd.displayAll();
				System.out.println(lt);
				break;
			default :
				System.out.println("Invalid Choice");
				break;
			}
		}while(choice!=2);

	}

}
