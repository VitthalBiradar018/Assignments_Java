package service;

import dao.EmployeDao;
import dao.EmployeDaoImpl;
import java.util.Scanner;
import beans.Employee;
public class EmployeServiceImpl implements EmployeService{
private EmployeDao edao;

public EmployeServiceImpl() {
	this.edao = new EmployeDaoImpl();
}
	@Override
	public boolean addEmp() {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter id:");
		int id = sc.nextInt();
		System.out.println("Enter name:");
		String nm = sc.next();
		System.out.println("Enter Salary:");
		double salary = sc.nextDouble();
		System.out.println("Enter department:");
		String dept = sc.next();
		System.out.println("Enter Desgignation:");
		String desg = sc.next();
		
		Employee e = new Employee(id,nm,salary,dept,desg);
		
		
			return edao.addAll(e);
		
		
		
	}
	@Override
	public void displaayAll() {
		edao.display();
		
	}	

}
