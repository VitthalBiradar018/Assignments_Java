package service;

public interface EmployeService {

	boolean addEmp();

	void displaayAll();

}
