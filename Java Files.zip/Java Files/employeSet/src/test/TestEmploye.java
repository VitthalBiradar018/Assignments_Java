package test;
import service.EmployeService;
import service.EmployeServiceImpl;


import java.util.Scanner;
public class TestEmploye {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
			EmployeService emps = new EmployeServiceImpl();
		int choice;
		do {
			System.out.println("1.add \n 2.display \n 3.exit");
			choice = sc.nextInt();
			switch(choice) {
			case 1:
				boolean status = emps.addEmp();
			if(status) {
				System.out.println("Adding successfull");
			}
			else {
				System.out.println("nullaaaa");
		}
			break;
			case 2:
				emps.displaayAll();
				break;
			case 3: 
				break;
			default:
				System.out.println("invalid no.");
				break;
		
		}
		}while(choice!=3);
		sc.close();
	}
}
