package dao;

import beans.Employee;

public interface EmployeDao {

	boolean addAll(Employee e);

	void display();

}
