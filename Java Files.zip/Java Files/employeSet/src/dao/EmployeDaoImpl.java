package dao;

import java.util.Set;
import java.util.HashSet;

import beans.Employee;

public class EmployeDaoImpl implements EmployeDao{

		static Set<Employee> empset; 
		static {
			empset = new HashSet<>();
		}
		@Override
		public boolean addAll(Employee e) {
		return empset.add(e);
		
		}
		@Override
		public void display() {
			empset.stream().forEach(System.out::println);
			
		}
		
		
}
