package dao;

import beans.Employee;

public interface TreeDao {

	void display();

	boolean add(int id, Employee e);

	Employee findId(int id);



}
