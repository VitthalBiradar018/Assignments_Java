package com.demo.test;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import com.demo.bean.*;

import java.util.Scanner;

public class TestReflaction {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("1. Friend  2. MyClass  3. Rectangle  4. Student");
		int choice =sc.nextInt();
		Object ob;
		if(choice==1) {
			 ob=new Friend(101,"abcd","23456");
		}else if(choice==2) {
			 ob=new MyClass(12,"Deepa");
		}else if(choice==3) {
			 ob=new Rectangle(12,23);
		}else {
			 ob=new Student(101,"qwer",88,99,78);
		}
		
		
		//MyClass ob=new MyClass(12,"Deepa");
		Class cls=ob.getClass();
		//to retrieve the constructors
		Constructor[] carr=cls.getConstructors();
		for(Constructor c:carr) {
			System.out.println(c.getName()+"---->"+c.getParameterCount());
		}
		//find method names
		Method[] marr=cls.getMethods();
		for(Method m:marr) {
			System.out.println(m.getName()+"---->"+m.getParameterCount());
		}
		//list of fields
		Field[] farr=cls.getDeclaredFields();
	    System.out.println("length :"+farr.length);
	    for(Field f1:farr) {
	    	System.out.println("in for");
	    	System.out.println("name : "+f1.getName());
	    	System.out.println("type :"+f1.getType().getName());
	    }
	    
	    // to change privte variabls value
	    farr[0].setAccessible(true);
	    farr[1].setAccessible(true);
	    try {
			farr[0].set(ob, 23);
			System.out.println(ob);
			farr[1].set(ob, "Kedar");
			System.out.println(ob);
		} catch (IllegalArgumentException | IllegalAccessException e) {
			e.printStackTrace();
		}
	    


	}

}
