package com.demo.bean;

public class Rectangle {
	int length;
	int height;
	public Rectangle(int length, int height) {
		super();
		this.length = length;
		this.height = height;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	
	
	public void area() {
		System.out.println(2*length*height);
	}

}
