package com.demo.bean;

public class Friend {
	private int fid;
	  private String name;
	  private String mobile;
		public Friend() {
			super();
		}
		
		public Friend(int fid) {
			super();
			this.fid = fid;
		}

		public Friend(int fid, String name, String mobile) {
			super();
			this.fid = fid;
			this.name = name;
			this.mobile = mobile;
		}
		public int getFid() {
			return fid;
		}
		public void setFid(int fid) {
			this.fid = fid;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getMobile() {
			return mobile;
		}
		public void setMobile(String mobile) {
			this.mobile = mobile;
		}
		@Override
		public String toString() {
			return "Friend [fid=" + fid + ", name=" + name + ", mobile=" + mobile + "]";
		}
		
		public void add(int a,int b, int c) {
			System.out.println(a+b+c);
		}
		

	
}
