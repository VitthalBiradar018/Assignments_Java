package com.demo.service;

public interface IStudentService {

}
