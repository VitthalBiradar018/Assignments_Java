package com.demo.test;
import com.demo.service.*;

public class StudentTest {

	public static void main(String[] args) {
		 
		StudentService s = new StudentService();
	
		s.addtolist();
	}

}
;
