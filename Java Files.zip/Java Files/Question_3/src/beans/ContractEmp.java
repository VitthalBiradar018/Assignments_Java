package beans;

import java.time.LocalDate;

public class ContractEmp extends Employee {
	private int hrs;
	private int rate;
	
	public ContractEmp(int id, String name, String mob, String emailid, String dept, String desig, LocalDate joindate,int hrs,int rate) {
		super(id, name, mob, emailid, dept, desig);
		this.hrs =hrs;
		this.rate = rate;
		// TODO Auto-generated constructor stub
	}

	public int getHrs() {
		return hrs;
	}

	public void setHrs(int hrs) {
		this.hrs = hrs;
	}

	public int getRate() {
		return rate;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}

	@Override
	public String toString() {
		return super.toString() + "\n ContractEmp [hrs=" + hrs + ", \n rate=" + rate + "]";
	}
	
	public void salary() {
		int sal = hrs* rate;
		System.out.println("Contract Emp : " + sal);
	}
	

	

}
