package beans;
import java.time.LocalDate;
import java.util.Scanner;

public class TestEmployee {

	public static void main (String[] args) {
		
		
	
		System.out.println("1. Salaried Emp \n2. Contract Emp \n3.Vendor ");
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		
		switch (choice) {
		case 1 :
			SalaryEmp semp = new SalaryEmp(12,"Vivek","8789" ,"vivek@gamil.com","RH", "mothi",LocalDate.of(2001, 12, 31), 50000);
			semp.salary();
			System.out.println(semp);
			break; 
		case 2 : 
			ContractEmp cemp = new ContractEmp(24, "ashwin", "324", "ash@23", "OCE", "lai_mothi", LocalDate.of(2014, 11, 21),5,300);
			cemp.salary();
			System.out.println(cemp);
			break;
		case 3:
			VendorEmp vemp =new VendorEmp(24, "ashwin", "324", "ash@23", "OCE", "lai_mothi", LocalDate.of(2014, 11, 21),100,6000);
			vemp.salary();
			System.out.println(vemp);
			break;
		default :
			System.out.println("Try Again...");
			
		}
		
	
	
	}	
}
