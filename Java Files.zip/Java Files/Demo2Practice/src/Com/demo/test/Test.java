package Com.demo.test;

import java.time.LocalDate;
import java.util.Scanner;

import Com.demo.beans.ContractEmp;
import Com.demo.beans.Employee;
import Com.demo.beans.Person;
import Com.demo.beans.SalariedEmp;
import Com.demo.beans.Vender;

public class Test {

	public static void main(String[] args) {
		
		
		Person p=new Person(11,"Rushi","12345");
		System.out.println(p);
		Employee e=new Employee(13,"yyy","45678","Hr","MGR",LocalDate.of(2023,3,24));
		System.out.println(e);
		SalariedEmp s=new SalariedEmp(14,"zzz","555","Hr","MGR",LocalDate.of(2023,3,24),67895);
		System.out.println(s);
		ContractEmp c=new ContractEmp(15,"ttttt","4444","admin","MGR",LocalDate.of(2023,3,24),30,6000);
		System.out.println(c);
	}


}
