package Com.demo.beans;

import java.time.LocalDate;

public class Employee extends Person {

	private String Dept;
	private String Desg;
	private LocalDate Doj;
	public Employee() {
		super();
	}
	public Employee(int id, String name, String mob,String dept, String desg,LocalDate doj) {
		super(id,name,mob);
		Dept = dept;
		Desg = desg;
		Doj = doj;
	}
	public String getDept() {
		return Dept;
	}
	public void setDept(String dept) {
		Dept = dept;
	}
	public String getDesg() {
		return Desg;
	}
	public void setDesg(String desg) {
		Desg = desg;
	}
	
	
	@Override
	public String toString() {
		return super.toString() + "Employee [Dept=" + Dept + ", Desg=" + Desg + "]";
	}
	
	
}
