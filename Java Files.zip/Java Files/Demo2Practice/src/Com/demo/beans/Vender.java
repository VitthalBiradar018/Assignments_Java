package Com.demo.beans;

import java.time.LocalDate;

public class Vender extends Employee {
	
	private double Amount;
	private int NoOfEmp;
	public Vender() {
		super();
	}
	public Vender(int id, String name, String mob,String dept, String desg,LocalDate doj,double amount, int noOfEmp) {
		super(id,name,mob,dept,desg,doj);
		Amount = amount;
		NoOfEmp = noOfEmp;
	}
	public double getAmount() {
		return Amount;
	}
	public void setAmount(double amount) {
		Amount = amount;
	}
	public int getNoOfEmp() {
		return NoOfEmp;
	}
	public void setNoOfEmp(int noOfEmp) {
		NoOfEmp = noOfEmp;
	}
	@Override
	public String toString() {
		return super.toString() + "Vender [Amount=" + Amount + ", NoOfEmp=" + NoOfEmp + "]";
	}
	
}
