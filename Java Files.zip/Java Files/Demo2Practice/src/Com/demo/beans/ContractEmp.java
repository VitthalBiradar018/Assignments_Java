package Com.demo.beans;

import java.time.LocalDate;

public class ContractEmp extends Employee {
	
	private int Hrs;
	private int Charges;
	public ContractEmp() {
		super();
	}
	public ContractEmp(int id, String name, String mob,String dept, String desg,LocalDate doj,int hrs, int charges) {
		super(id,name,mob,dept,desg,doj);
		Hrs = hrs;
		Charges = charges;
	}
	public int getHrs() {
		return Hrs;
	}
	public void setHrs(int hrs) {
		Hrs = hrs;
	}
	public int getCharges() {
		return Charges;
	}
	public void setCharges(int charges) {
		Charges = charges;
	}
	@Override
	public String toString() {
		return super.toString()+"ContractEmp [Hrs=" + Hrs + ", Charges=" + Charges + "]";
	}
	
	

}
