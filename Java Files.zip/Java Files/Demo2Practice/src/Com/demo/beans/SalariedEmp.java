package Com.demo.beans;

import java.time.LocalDate;

public class SalariedEmp extends Employee {
	
	private double Salary;
	private double Bonus;
	public SalariedEmp() {
		super();
	}
	public SalariedEmp(int id, String name, String mob,String dept, String desg,LocalDate doj,double salary) {
		super(id,name,mob,dept,desg,doj);
		Salary = salary;
		Bonus = 0.10*Salary;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(double salary) {
		Salary = salary;
	}
	public double getBonus() {
		return Bonus;
	}
	public void setBonus(double bonus) {
		Bonus = bonus;
	}
	@Override
	public String toString() {
		return super.toString() + "SalariedEmp [Salary=" + Salary + ", Bonus=" + Bonus + "]";
	}
	
	

}
