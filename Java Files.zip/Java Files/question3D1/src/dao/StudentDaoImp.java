package dao;
import bean.Student;
public class StudentDaoImp implements StudentDao {

	
	static Student std[] = new Student[2]; 
	static {
	std[0] = new Student(1,"Ady",10,20,30);
	std[1] = new Student(2,"sodi", 40,50,60);
	
	}
	public void display() {
		
		for (Student s: std) {
			System.out.println(s);
		}
		
		
	}
	@Override
	public void search(int id) {
		for(int i =0 ; i<std.length ; i++) {
			if (std[i].getId() == id) { 
				System.out.println(std[i]);
			}			
		}
	}
	
	public void searchName(String n) {
		for (int i = 0 ; i< std.length; i++) {
			if (std[i].getName().equals(n)) {
				System.out.println(std[i]);
			}
		}
	}
	@Override
	public void calculate() {
		for (int i = 0; i < std.length; i++) {
		float marks = std[i].getM1() + std[i].getM2() + std[i].getM3(); 
		float gpa = (marks*3)/100;
		
		System.out.println("gpa of "+std[i].getName()+"= " + gpa);
		}
		
	}
	
	
	
		
	
	

}
