package service;
import dao.StudentDao;
import dao.StudentDaoImp;

public class StudentService implements StudentSI {
	private StudentDao sd;
	
	public StudentService() {
		this.sd = new StudentDaoImp();
	}
	public void displayAll() {
		sd.display();
		
	}
	public void searchId(int id) {
		
		sd.search(id);
		
	}
	@Override
	public void searchName(String name) {
		
		sd.searchName(name);
	}
	@Override
	public void CalulateGPA() {
		sd.calculate();
		
	}
	
	
	
	

}
