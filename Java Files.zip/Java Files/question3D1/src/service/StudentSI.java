package service;

public interface StudentSI {
	void displayAll();

	void searchId(int id);

	void searchName(String name);

	void CalulateGPA();



}
